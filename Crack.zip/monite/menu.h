#import <UIKit/UIKit.h>

@interface _m1Bf03WvGkXe : UIViewController <UIGestureRecognizerDelegate, UITextFieldDelegate>
@property (nonatomic, strong) UIView *menuContainer;
@property (nonatomic, strong) UIScrollView *sidebarScroll;
@property (nonatomic, strong) UIColor *panelAccentColor;
@end
