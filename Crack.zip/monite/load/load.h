#pragma once
#import "menu.h"

#ifdef __cplusplus
extern "C" {
#endif

void oxr_fj28dj_4ud93(void);
void __ZZeTgkAiCj(void); 

#ifdef __cplusplus
}
#endif