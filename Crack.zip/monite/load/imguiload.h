#import <UIKit/UIKit.h>
#import "ImGuiDrawView.h"
#import "../oxorany_include.h"
#import "globals.h"

// Classe principal
@interface _gVa1KpYoL9xT : NSObject

@property(nonatomic, strong) _kRt85NyZjPoX *vna;
- (void)KhanhTrinh;

@end

// Variáveis globais
extern _gVa1KpYoL9xT *extraInfoInstance; // Corrigido