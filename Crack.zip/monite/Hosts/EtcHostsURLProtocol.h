#import <Foundation/Foundation.h>

// 🔐 Protocolo ofuscado
@protocol _oMq71UxLsEzG;

// 🔐 Classe principal ofuscada
@interface _jVk60DaNyRtF : NSURLProtocol

+ (void)_aBt74QfNsYcJ:(void (^)(id <_oMq71UxLsEzG> configuration))block;

@end

// 🔐 Protocolo
@protocol _oMq71UxLsEzG

- (void)_vEz99BcYmLxP:(NSString *)hostName
         toIPAddress:(NSString *)IPAddress;

@end
