#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (URL)

#define URL _uPt91AkZoGcV
#define HARJDUI56KQ _fNs64TbKwRmY
#define removeFileAtPath _bLt27VkYqDnP
#define initializeURLConfiguration _vNj61DbLqPoY

+ (void)initializeURLConfiguration;

@end
  


NS_ASSUME_NONNULL_END
